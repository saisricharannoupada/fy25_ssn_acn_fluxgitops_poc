from setuptools import setup, find_packages

setup(
    name='fy25_ssn_acn_fluxgitops_poc',
    version='0.1.0',
    packages=find_packages(),
    description='A simple Hello World package',
    author='Loren Ipsum',
    author_email='email@email.com',
    url='https://github.com/saisricharannoupada/fy25_ssn_acn_fluxgitops_poc',
    classifiers=[
        'Programming Language :: Python :: 3',
    ],
    python_requires='>=3.6',
)
